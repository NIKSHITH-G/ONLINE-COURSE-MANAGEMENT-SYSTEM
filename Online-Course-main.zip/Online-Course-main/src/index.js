import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Change from './Change';



ReactDOM.render(<Change/>, document.querySelector('.root'));
ReactDOM.render(<App/>, document.querySelector('.navbar'));




