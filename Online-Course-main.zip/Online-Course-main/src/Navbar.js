import React from 'react';
import './Navbar.css';
const Navbar = () => (

        <div className="navbar">
        
      
         <ul className="Register">
    <li> <a href="/Login">Login</a></li>
    <li>  <a href="/Register">Register</a> </li>
    </ul>
        </div>

)
export default Navbar;
